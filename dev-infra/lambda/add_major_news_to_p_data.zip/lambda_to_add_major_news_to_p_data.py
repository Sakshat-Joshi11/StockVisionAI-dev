import json
import boto3
import requests
import os
import csv
from io import StringIO
from datetime import datetime

# AWS S3 Configuration
S3_BUCKET = os.environ.get("RAW_BUCKET_NAME")

# News API Configuration
NEWS_API_KEY = os.environ.get("NEWS_API_KEY")
NEWS_API_URL = "https://api.marketaux.com/v1/news/all"

s3 = boto3.client("s3")

def fetch_news(ticker):
    """Fetch major news headlines related to the given stock ticker."""
    params = {
        "api_token": NEWS_API_KEY,
        "symbols": ticker,
        "language": "en",
        "limit": 5
    }

    response = requests.get(NEWS_API_URL, params=params)

    if response.status_code == 200:
        data = response.json()
        if "data" in data:
            return [article.get("title", "N/A") for article in data["data"]]
        else:
            print(f"Unexpected API response format: {data}")
            return []
    else:
        print(f"Error fetching news: {response.text}")
        return []

def update_csv_with_news(s3_object_key, ticker):
    """Fetch the CSV file, add news incrementally, and upload it back to S3."""
    # Read CSV from S3
    obj = s3.get_object(Bucket=S3_BUCKET, Key=s3_object_key)
    csv_content = obj["Body"].read().decode("utf-8")

    # Read CSV rows
    csv_reader = csv.reader(StringIO(csv_content))
    rows = [row for row in csv_reader]

    # Fetch news data
    news_data = fetch_news(ticker)

    # Ensure header has 'news' columns
    header = rows[0]
    existing_news_cols = [col for col in header if col.startswith("news")]
    num_existing_news_cols = len(existing_news_cols)

    # Add new column headers as needed
    for i in range(len(news_data)):
        header.append(f"news{num_existing_news_cols + i + 1}")

    # Append news data to rows
    for i in range(1, len(rows)):
        for j in range(len(news_data)):
            rows[i].append(news_data[j])

    # Write back to CSV format
    output = StringIO()
    csv_writer = csv.writer(output)
    csv_writer.writerows(rows)
    updated_csv_data = output.getvalue()

    # Upload updated CSV back to S3
    s3.put_object(
        Bucket=S3_BUCKET,
        Key=s3_object_key,
        Body=updated_csv_data,
        ContentType="text/csv"
    )

def lambda_handler(event, context):
    """AWS Lambda function to fetch and store news related to stock data."""
    try:
        for record in event.get("Records", []):
            s3_object_key = record["s3"]["object"]["key"]
            parts = s3_object_key.split("/")
            if len(parts) < 5:
                continue

            ticker, year, month, date = parts[1], parts[2], parts[3], parts[4]

            # Update CSV with news
            update_csv_with_news(s3_object_key, ticker)

        return {"statusCode": 200, "message": "News data appended successfully.", "s3_key": s3_object_key}
    except Exception as e:
        print(f"Error: {str(e)}")
        return {"statusCode": 500, "message": "Internal server error."}
