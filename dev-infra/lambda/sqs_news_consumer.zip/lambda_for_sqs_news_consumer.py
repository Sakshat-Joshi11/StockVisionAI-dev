import json
import boto3
import requests
import os
import csv
import time
from datetime import datetime
from io import StringIO

# AWS S3 Configuration
S3_BUCKET = os.environ.get("RAW_BUCKET_NAME")
S3_PREFIX = "partitioned_raw/{ticker}/{year}/{month}/{date}/data.csv"

# Alpaca News API Configuration
ALPACA_API_KEY_ID = os.environ.get("APCA_API_KEY_ID")
ALPACA_SECRET_KEY = os.environ.get("APCA_API_SECRET_KEY")
NEWS_API_URL = os.environ.get("NEWS_API_URL")

s3 = boto3.client("s3")

# Meta file to avoid duplicate entries
META_FILE = "/tmp/news_meta.json"

MONTH_MAP = {
    "January": "01", "February": "02", "March": "03", "April": "04",
    "May": "05", "June": "06", "July": "07", "August": "08",
    "September": "09", "October": "10", "November": "11", "December": "12"
}

def load_meta():
    if os.path.exists(META_FILE):
        with open(META_FILE, "r") as f:
            return json.load(f)
    return {}

def save_meta(meta):
    with open(META_FILE, "w") as f:
        json.dump(meta, f, indent=2)

def fetch_news_with_backoff(ticker, date, retries=5):
    """
    Fetch news data from the Alpaca API with exponential backoff for handling rate limits.
    """
    start_date = date.strftime("%Y-%m-%dT00:00:00Z")
    end_date = date.strftime("%Y-%m-%dT23:59:59Z")
    params = {
        "symbols": ticker,
        "start": start_date,
        "end": end_date,
        "sort": "desc",
        "limit": 5
    }
    headers = {
        "APCA-API-KEY-ID": ALPACA_API_KEY_ID,
        "APCA-API-SECRET-KEY": ALPACA_SECRET_KEY,
        "Accept": "application/json"
    }
    wait_time = 1  # Initial wait time
    for attempt in range(retries):
        response = requests.get(NEWS_API_URL, params=params, headers=headers)
        if response.status_code == 429:  # Too Many Requests
            print(f"Rate limited. Retrying in {wait_time} seconds (attempt {attempt + 1}/{retries})...")
            time.sleep(wait_time)
            wait_time *= 2  # Exponential backoff
        elif response.status_code == 200:
            return response.json().get("news", [])
        else:
            response.raise_for_status()

    raise Exception(f"Max retries exceeded while fetching news for {ticker}.")

def lambda_handler(event, context):
    try:
        meta = load_meta()
        for record in event.get("Records", []):
            try:
                # Parse the body as JSON
                message_body = json.loads(record.get("body", "{}"))

                # Extract S3 information
                s3_info = message_body.get("s3", {})
                bucket_name = s3_info.get("bucket", {}).get("name")
                object_key = s3_info.get("object", {}).get("key")

                if not bucket_name or not object_key:
                    print("Missing 'bucket' or 'object' information in SQS message.")
                    continue

                parts = object_key.split("/")
                if len(parts) < 5:
                    print(f"Invalid S3 key format: {object_key}")
                    continue

                ticker, year, month, date = parts[1], parts[2], parts[3], parts[4]
                month_numeric = MONTH_MAP.get(month, month.zfill(2))
                meta_key = f"{ticker}_{year}-{month_numeric}-{date}"

                if meta.get("processed", {}).get(meta_key):
                    print(f"News already processed for {meta_key}")
                    continue

                # Parse date
                try:
                    date_obj = datetime.strptime(f"{year}-{month_numeric}-{date}", "%Y-%m-%d")
                except ValueError as ve:
                    print(f"Date parsing error for {ticker}-{year}-{month_numeric}-{date}: {ve}")
                    continue

                # Fetch news with backoff
                news_data = fetch_news_with_backoff(ticker, date_obj)
                if not news_data:
                    print(f"No news for {ticker} on {date_obj.strftime('%Y-%m-%d')}")
                    continue

                # Extract news headlines
                headlines = [article.get("headline", "") for article in news_data][:5]
                news_columns = {f"news{i+1}": headline for i, headline in enumerate(headlines)}

                # Read existing CSV from S3
                csv_obj = s3.get_object(Bucket=bucket_name, Key=object_key)
                csv_content = csv_obj['Body'].read().decode('utf-8')

                csv_reader = csv.DictReader(StringIO(csv_content))
                updated_rows = []

                for row in csv_reader:
                    row.update(news_columns)
                    updated_rows.append(row)

                # Write updated CSV to string
                output = StringIO()
                fieldnames = csv_reader.fieldnames + list(news_columns.keys())
                fieldnames = list(dict.fromkeys(fieldnames))  # Remove duplicates

                writer = csv.DictWriter(output, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(updated_rows)

                # Upload updated CSV to S3
                s3.put_object(
                    Bucket=bucket_name,
                    Key=object_key,
                    Body=output.getvalue().encode("utf-8"),
                    ContentType="text/csv"
                )

                print(f"Updated {object_key} with {len(news_columns)} news columns.")
                meta.setdefault("processed", {})[meta_key] = True
                save_meta(meta)

            except Exception as e:
                print(f"Unexpected error: {e}")
                continue

        return {"statusCode": 200, "message": "News data stored successfully."}

    except Exception as e:
        print(f"Error: {str(e)}")
        return {"statusCode": 500, "message": "Internal server error."}
