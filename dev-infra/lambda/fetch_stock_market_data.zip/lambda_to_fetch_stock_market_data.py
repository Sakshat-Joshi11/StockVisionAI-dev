import json
import boto3
import yfinance as yf
import pandas as pd
import io
import os

def get_config_from_s3(bucket_name, config_file):
    """Fetch config file from S3."""
    s3 = boto3.client('s3')
    try:
        # Get the config file from S3 bucket
        response = s3.get_object(Bucket=bucket_name, Key=config_file)
        # Parse the content of the file as JSON
        config = json.loads(response['Body'].read().decode('utf-8'))
        return config
    except Exception as e:
        print(f"Error reading config file from S3: {str(e)}")
        return {}

def fetch_stock_data(ticker, start_date, end_date, interval):
    """Fetch historical stock data from Yahoo Finance."""
    print(f"Fetching data for {ticker} from {start_date} to {end_date} with interval {interval}...")
    data = yf.download(ticker, start=start_date, end=end_date, interval=interval)
    if data.empty:
        print(f"No data found for {ticker}.")
        return None
    return data

def upload_to_s3(data, ticker, bucket_name):
    """Upload consolidated stock data to S3."""
    s3 = boto3.client("s3")
    
    # Convert the entire dataframe to CSV
    csv_buffer = io.StringIO()
    data.to_csv(csv_buffer, index=False)  # Convert the entire data to CSV format

    # Define the S3 path where the consolidated file will be uploaded
    s3_path = f"consolidated_raw/{ticker}/{ticker}_consolidated_data.csv"
    
    # Upload the consolidated CSV file to S3
    s3.put_object(Bucket=bucket_name, Key=s3_path, Body=csv_buffer.getvalue())
    print(f"Uploaded consolidated {ticker} data to s3://{bucket_name}/{s3_path}")

def lambda_handler(event, context):
    """AWS Lambda entry point."""
    # Fetch the config from S3
    bucket_name = os.environ.get("CONFIG_BUCKET_NAME")  # Optional: Use Lambda environment variables for bucket name
    config_file = os.environ.get("CONFIG_FILE_PATH")
    config = get_config_from_s3(bucket_name, config_file)
    
    if not config:
        return {"statusCode": 400, "body": "Error fetching config from S3."}

    # Extract configuration values
    stock_data = config.get("stock_data", {})
    tickers = stock_data.get("tickers")
    start_date = stock_data.get("start_date")
    end_date = stock_data.get("end_date")
    interval = stock_data.get("interval")

    if not tickers or not start_date or not end_date or not interval:
        return {"statusCode": 400, "body": "Missing required parameters in config."}

    # Get the S3 bucket name for uploading the consolidated data
    bucket_name = config["aws"]["s3_bucket_name"]

    for ticker in tickers:
        # Fetch stock data for each ticker
        data = fetch_stock_data(ticker, start_date, end_date, interval)
        if data is None:
            continue
        
        # Upload consolidated data to S3
        upload_to_s3(data, ticker, bucket_name)
    
    return {"statusCode": 200, "body": json.dumps({"message": "Consolidated data fetched and stored successfully."})}
