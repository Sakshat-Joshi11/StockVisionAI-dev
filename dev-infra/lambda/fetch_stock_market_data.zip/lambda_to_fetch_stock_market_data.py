import json
import boto3
import yfinance as yf
import pandas as pd
import datetime
import os
from io import StringIO

def fetch_stock_data(ticker, start_date, end_date, interval):
    """Fetch historical stock data from Yahoo Finance with additional indicators."""
    print(f"Fetching data for {ticker} from {start_date} to {end_date} with interval {interval}...")

    # Download stock data
    data = yf.download(ticker, start=start_date, end=end_date, interval=interval)
    
    # Print the first few rows for debugging
    print("Raw Data Columns:", data.columns)
    print(data.head())

    if data.empty:
        print(f"No data found for {ticker}.")
        return None
    
    # Convert MultiIndex columns to single level (if applicable)
    if isinstance(data.columns, pd.MultiIndex):
        data.columns = ['_'.join(col).strip() if isinstance(col, tuple) else col for col in data.columns]
    else:
        data.columns = [col.replace(' ', '_') for col in data.columns]

    # Print updated column names
    print("Processed Data Columns:", data.columns)

    data.reset_index(inplace=True)  # Ensure 'Date' is a column

    close_col = f"Close_{ticker}"
    
    # Ensure the 'Close' column exists
    if close_col not in data.columns:
        raise KeyError(f"'{close_col}' column not found. Available columns: {data.columns}")

    # Ensure 'Adj_Close' column exists
    data["Adj_Close"] = data.get(f"Adj_Close_{ticker}", data[close_col])

    # Compute Technical Indicators
    data['Returns'] = data['Adj_Close'].pct_change()  # Daily returns
    data['Rolling_Volatility'] = data['Returns'].rolling(window=14).std()  # 14-day rolling volatility
    
    # RSI Calculation
    delta = data['Adj_Close'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
    rs = gain / loss
    data['RSI'] = 100 - (100 / (1 + rs))

    # MACD Calculation
    data['MACD'] = data['Adj_Close'].ewm(span=12, adjust=False).mean() - data['Adj_Close'].ewm(span=26, adjust=False).mean()
    data['MACD_Signal'] = data['MACD'].ewm(span=9, adjust=False).mean()

    # Bollinger Bands
    data['20_SMA'] = data['Adj_Close'].rolling(window=20).mean()
    data['Upper_Band'] = data['20_SMA'] + (data['Adj_Close'].rolling(window=20).std() * 2)
    data['Lower_Band'] = data['20_SMA'] - (data['Adj_Close'].rolling(window=20).std() * 2)

    return data

def upload_to_s3(data, bucket, file_path):
    """Upload data to S3 bucket."""
    csv_buffer = StringIO()
    data.to_csv(csv_buffer, index=False)
    s3 = boto3.client('s3')
    s3.put_object(Bucket=bucket, Key=file_path, Body=csv_buffer.getvalue())
    print(f"Uploaded {file_path} to {bucket}")

def lambda_handler(event, context):
    """AWS Lambda function entry point."""
    try:
        # Load environment variables
        raw_bucket = os.getenv("RAW_BUCKET_NAME")
        config_bucket = os.getenv("CONFIG_BUCKET_NAME")
        config_file_path = os.getenv("CONFIG_FILE_PATH")
        
        if not raw_bucket or not config_bucket or not config_file_path:
            raise ValueError("Missing required environment variables")
        
        # Load config from S3
        s3 = boto3.client('s3')
        config_obj = s3.get_object(Bucket=config_bucket, Key=config_file_path)
        config = json.loads(config_obj['Body'].read().decode('utf-8'))
        
        tickers = config["stock_data"]["tickers"]
        interval = config["stock_data"]["interval"]
        start_date = config["stock_data"]["start_date"]
        end_date = config["stock_data"]["end_date"]
        
        for ticker in tickers:
            data = fetch_stock_data(ticker, start_date, end_date, interval)
            
            if data is not None:
                file_path = f"consolidated_raw/{ticker}/{ticker}_data_{end_date}.csv"
                upload_to_s3(data, raw_bucket, file_path)
        
        return {
            'statusCode': 200,
            'body': json.dumps('Stock data successfully processed and uploaded!')
        }
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps(f"Error: {str(e)}")
        }
