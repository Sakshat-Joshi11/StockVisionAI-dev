import json
import boto3
import os

# AWS Configuration
S3_BUCKET = os.environ.get("RAW_BUCKET_NAME")
S3_PREFIX = "partitioned_raw/"
SQS_QUEUE_URL = os.environ.get("SQS_QUEUE_URL")

s3 = boto3.client("s3")
sqs = boto3.client("sqs")


def list_s3_objects():
    """
    List all objects in the specified S3 bucket and prefix.
    """
    response = s3.list_objects_v2(Bucket=S3_BUCKET, Prefix=S3_PREFIX)
    return response.get("Contents", [])


def extract_message_details(s3_key):
    """
    Extract details and format the message to match the expected structure.
    """
    parts = s3_key.split("/")
    if len(parts) >= 5:
        return {
            "s3": {
                "bucket": {"name": S3_BUCKET},
                "object": {"key": s3_key}
            }
        }
    return None



def send_to_sqs(message):
    """
    Send a single message to the SQS queue.
    """
    sqs.send_message(
        QueueUrl=SQS_QUEUE_URL,
        MessageBody=json.dumps(message)
    )


def lambda_handler(event, context):
    """
    Lambda handler to scan S3 and send messages to SQS.
    """
    try:
        s3_objects = list_s3_objects()
        for obj in s3_objects:
            s3_key = obj["Key"]
            # Skip non-data files or folders
            if not s3_key.endswith("data.csv"):
                continue

            message_details = extract_message_details(s3_key)
            if message_details:
                send_to_sqs(message_details)
                print(f"Sent message to SQS: {message_details}")

        return {"statusCode": 200, "message": "All messages sent to SQS successfully."}

    except Exception as e:
        print(f"Error: {str(e)}")
        return {"statusCode": 500, "message": "Internal server error."}