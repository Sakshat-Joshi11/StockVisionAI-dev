import boto3
import pandas as pd
import io
import os

def lambda_handler(event, context):
    """
    AWS Lambda function to partition consolidated stock market data.
    Triggered when a new consolidated file is uploaded to S3.
    """
    s3_client = boto3.client('s3')

    # Environment variable for bucket name
    bucket_name = os.getenv("RAW_BUCKET_NAME")
    if not bucket_name:
        print("RAW_BUCKET_NAME environment variable is not set.")
        return

    # Extract bucket name and file key from the event
    try:
        record = event['Records'][0]
        key = record['s3']['object']['key']
    except KeyError:
        print("Invalid event structure")
        return

    print(f"Triggered by file: s3://{bucket_name}/{key}")

    # Extract metadata from key (Expected: consolidated_raw/{ticker}/{ticker}_data_{end_date}.csv)
    parts = key.split('/')
    if len(parts) < 3:
        print(f"Unexpected file structure: {key}")
        return

    ticker = parts[1]
    filename = parts[2]

    # Extract end_date from filename (Expected format: {ticker}_data_{end_date}.csv)
    try:
        file_date = filename.replace(f"{ticker}_data_", "").replace(".csv", "")
    except Exception as e:
        print(f"Error extracting date from filename: {e}")
        return

    year, month, day = file_date.split('-')

    # Download the consolidated file from S3
    try:
        response = s3_client.get_object(Bucket=bucket_name, Key=key)
        raw_data = response['Body'].read()
    except Exception as e:
        print(f"Error downloading file from S3: {e}")
        return

    # Load the CSV into a Pandas DataFrame
    try:
        df = pd.read_csv(io.BytesIO(raw_data))
    except Exception as e:
        print(f"Error reading CSV: {e}")
        return

    # Ensure necessary columns exist
    if 'Date' not in df.columns:
        print("Required column 'Date' not found in the file.")
        return

    # Convert Date column to datetime
    df['Date'] = pd.to_datetime(df['Date'], errors='coerce')

    # Partition data by date
    for date, partition in df.groupby(df['Date'].dt.date):
        partition_buffer = io.StringIO()
        partition.to_csv(partition_buffer, index=False)
        partition_buffer.seek(0)

        # Define partitioned S3 key
        partition_key = f"partitioned_raw/{ticker}/{year}/{month}/{date}/data.csv"

        # Upload the partition to S3
        try:
            s3_client.put_object(
                Bucket=bucket_name,
                Key=partition_key,
                Body=partition_buffer.getvalue()
            )
            print(f"Uploaded partition: s3://{bucket_name}/{partition_key}")
        except Exception as e:
            print(f"Error uploading partition to S3: {e}")

    print("Partitioning complete!")
