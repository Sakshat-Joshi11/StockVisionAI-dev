import boto3
import pandas as pd
import numpy as np
import os
import io

def lambda_handler(event, context):
    """
    AWS Lambda function to partition a consolidated CSV file into smaller files by ticker and date.
    
    Triggered when a new consolidated file is uploaded to S3.
    
    :param event: S3 event data
    :param context: AWS Lambda context
    """
    s3_client = boto3.client('s3')

    # Extract bucket name and file key from the event
    bucket_name = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']

    print(f"Triggered by file: s3://{bucket_name}/{key}")

    # Download the consolidated file from S3
    try:
        response = s3_client.get_object(Bucket=bucket_name, Key=key)
        consolidated_file = response['Body'].read()
    except Exception as e:
        print(f"Error downloading file from S3: {e}")
        return

    # Load the file into a Pandas DataFrame
    try:
        df = pd.read_csv(io.BytesIO(consolidated_file))
    except Exception as e:
        print(f"Error reading CSV: {e}")
        return

    # Ensure date and ticker columns exist
    if 'Date' not in df.columns or 'Ticker' not in df.columns:
        print("Required columns 'Date' and 'Ticker' not found in the file.")
        return

    # Convert the Date column to datetime
    df['Date'] = pd.to_datetime(df['Date'], errors='coerce')

    # Partition data by Ticker and Date
    for ticker, ticker_df in df.groupby('Ticker'):
        for date, partition in ticker_df.groupby(ticker_df['Date'].dt.date):
            # Save each partition as a CSV in-memory
            partition_buffer = io.StringIO()
            partition.to_csv(partition_buffer, index=False)
            partition_buffer.seek(0)

            # Define the S3 key for the partition
            partition_key = f"partitioned_raw/{ticker}/{date}/data.csv"

            # Upload the partition to S3
            try:
                s3_client.put_object(
                    Bucket=bucket_name,
                    Key=partition_key,
                    Body=partition_buffer.getvalue()
                )
                print(f"Uploaded partition: s3://{bucket_name}/{partition_key}")
            except Exception as e:
                print(f"Error uploading partition to S3: {e}")

    print("Partitioning complete!")
