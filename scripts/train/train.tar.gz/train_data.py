import os
import tensorflow as tf
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split

# Define constants
MODEL_OUTPUT_DIR = os.environ.get('SM_MODEL_DIR')  # SageMaker environment variable to store the model

# Load data
def load_data():
    # The training data is passed as S3 path in the estimator
    train_data_path = '/opt/ml/input/data/train/train.csv'  # This is where SageMaker puts the data

    # Read the CSV file
    data = pd.read_csv(train_data_path)
    return data

# Preprocess the data
def preprocess_data(data):
    # Map dataset-specific columns to generic names
    required_columns = {
        'close_aapl': 'Close',
        'high_aapl': 'High',
        'low_aapl': 'Low',
        'volume_aapl': 'Volume'
    }
    # Rename columns to match the expected names
    data = data.rename(columns=required_columns)

    # Validate that all required columns are present
    missing_columns = [col for col in required_columns.values() if col not in data.columns]
    if missing_columns:
        raise ValueError(f"Missing columns in dataset: {missing_columns}")

    # Select features and target
    features = data[['Close', 'High', 'Low', 'Volume']].values
    target = data['Close'].shift(-1).dropna().values  # Predict the next day's close price

    # Normalize the features
    scaler = MinMaxScaler(feature_range=(0, 1))
    features_scaled = scaler.fit_transform(features[:-1])  # Align features with target

    return features_scaled, target, scaler

# Define the model
def build_model(input_shape):
    model = tf.keras.Sequential([
        tf.keras.layers.LSTM(50, return_sequences=True, input_shape=input_shape),
        tf.keras.layers.LSTM(50, return_sequences=False),
        tf.keras.layers.Dense(1)
    ])
    model.compile(optimizer='adam', loss='mean_squared_error')
    return model

# Main function to start training
def main():
    # Load and preprocess the data
    data = load_data()
    features, target, scaler = preprocess_data(data)

    # Split the data into training and validation sets
    X_train, X_val, y_train, y_val = train_test_split(features, target, test_size=0.2, shuffle=False)

    # Reshape the data for LSTM (samples, timesteps, features)
    X_train = X_train.reshape((X_train.shape[0], 1, X_train.shape[1]))
    X_val = X_val.reshape((X_val.shape[0], 1, X_val.shape[1]))

    # Build the model
    model = build_model(input_shape=(X_train.shape[1], X_train.shape[2]))

    # Train the model
    model.fit(X_train, y_train, epochs=10, batch_size=32, validation_data=(X_val, y_val))

    # Save the trained model
    model.save(os.path.join(MODEL_OUTPUT_DIR, 'model.h5'))  # Save the model in the correct directory for SageMaker

if __name__ == '__main__':
    main()
